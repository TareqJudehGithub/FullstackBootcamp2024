﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using HumanResourcesApp.ViewModels;

namespace HumanResourcesApp.Controllers
{
    public class AccountController : Controller
    {
        #region Fields
        private UserManager<IdentityUser> _userManager;
        private SignInManager<IdentityUser> _signInManager;
        private RoleManager<IdentityRole> _roleManager;
        #endregion

        #region Constructors
        public AccountController
            (
            UserManager<IdentityUser> userManager,
            SignInManager<IdentityUser> signInManager,
            RoleManager<IdentityRole> roleManager
            )
        {
            // Map each manager to its property in ViewModel
            this._userManager = userManager;
            this._signInManager = signInManager;    
            this._roleManager = roleManager;
        }

        #endregion

        #region Action methods
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel register)
        {
            if ( ModelState.IsValid)
            {
                IdentityUser identityUser = new IdentityUser
                {
                    UserName = register.Username,
                    Email = register.Email,
                    PhoneNumber = register.PhoneNumber
                };
                var identityResult = await _userManager.CreateAsync(identityUser, register.Password);

                if (identityResult.Succeeded)
                {
                    await _userManager.AddToRoleAsync(identityUser, "User");  // 2nd arguement is the role that we enter in DB under Name column
                    // in table ASPNETROLES table.
                    return RedirectToAction("Login");  // Login is not yet implememented
                }
                else
                {
                    foreach (var error in identityResult.Errors)
                    {
                        ModelState.AddModelError(error.Code, error.Description);
                    }
                }
            }

            return View();
        }
        #endregion
    }
}
