﻿using System.ComponentModel.DataAnnotations;

namespace HumanResourcesApp.Models
{
    public class Employee
    {
        // Data Annotation
        [Required]
        [Display(Name = "Employee ID")]
        [Range(0, int.MaxValue)]  // Check input is positive value        
        public int Id { get; set; }

        [Required]
        [Display(Name = "Employee Name")]
        [StringLength(20)]  // Check input length
        public string EmployeeName { get; set; }

        [Required]
        [Display(Name = "Department")]
        public int DepartmentId { get; set; }

        [Required]
        [Display(Name = "Department")]
        public string DepartmentName { get; set; }

        [Required]
        [Display(Name = "Hiring Date")]
        public DateOnly HiringDate { get; set; }
    }
}
