﻿using HumanResourcesApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace HumanResourcesApp.Controllers
{
    public class DepartmentController : Controller
    {
        public static List<Department> _departmentsList = new List<Department>
         {
            new Department {Id = 1, DepartmentName = "Developers"},
            new Department {Id = 2, DepartmentName = "Support"},
            new Department {Id = 3, DepartmentName = "Cyber Security"}
        };

        [HttpGet]
        public IActionResult Index()
        {
            return View(_departmentsList);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Department department)
        {
            _departmentsList.Add(department);
            return RedirectToAction(nameof(Index));
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var model = _departmentsList.Where(dept => dept.Id == id).FirstOrDefault();

            return View("Create", model);  // View(ViewName, Object)
        }
        public IActionResult Edit(int id, Department department)
        {
            var model = _departmentsList.Where(dept => dept.Id == id).FirstOrDefault();

            model.DepartmentName = department.DepartmentName;

            return RedirectToAction(nameof(Index));
        }
        //[HttpGet]
        //public IActionResult Delete(int Id)
        //{
        //    var model = _departmentsList.Find(dept => dept.Id == Id);
        //    return View(model);
        //}
        [HttpGet]
        public IActionResult Delete(int id, Department department)
        {
            var model = _departmentsList.Find(dept => dept.Id == id);
            if (model != null)
            {
            _departmentsList.Remove(model);
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
