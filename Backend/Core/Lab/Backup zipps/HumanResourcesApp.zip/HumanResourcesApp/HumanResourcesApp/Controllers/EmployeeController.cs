﻿using HumanResourcesApp.Models;
using Microsoft.AspNetCore.Mvc;


namespace HumanResourcesApp.Controllers
{
    public class EmployeeController : Controller
    {
        private static List<Employee> _employeesList = new List<Employee>
        {
            new Employee {Id = 1, EmployeeName = "John Smith", Department = "IT"},
            new Employee {Id = 2, EmployeeName = "Sarah Adams", Department = "HR"},
            new Employee {Id = 3, EmployeeName = "Ali Hamed", Department = "Marketing"}
        };

        // Show all Employees
        public IActionResult Index()
        {
            return View(_employeesList);
        }

        // Create new employee menu
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // Add the created employee from Create - Get to _employeeList
        [HttpPost]
        public IActionResult Create(Employee employee)
        {
            _employeesList.Add(employee);
            return RedirectToAction("index");
        }
        // Edit Employee Menu
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var emp = _employeesList.Where(emp => emp.Id == id).FirstOrDefault();

            return View(emp);
        }
        // Update edited employee information from Edit-Get and save them.
        [HttpPost]
        public IActionResult Edit(int id, Employee employee)
        {
            var emp = _employeesList.Where(emp => emp.Id == id).FirstOrDefault();

            emp.EmployeeName = employee.EmployeeName;
            emp.Department = employee.Department;
            emp.HiringDate = employee.HiringDate;

            return RedirectToAction("index");
        }
        // Employee Delete menu
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var model = _employeesList.Find(emp => emp.Id == id);
            return View(model);
        }
        // Remove selected employee from _employeeList
        [HttpPost]
        public IActionResult Delete(int id, Employee employee)
        {
            var model = _employeesList.Find(emp => emp.Id == id);
            _employeesList.Remove(model);
            return RedirectToAction(nameof(Index));
        }
    }
}
