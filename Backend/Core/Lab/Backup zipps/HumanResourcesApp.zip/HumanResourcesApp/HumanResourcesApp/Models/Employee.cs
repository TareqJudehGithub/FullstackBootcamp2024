﻿namespace HumanResourcesApp.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string EmployeeName { get; set; }
        public string Department { get; set; }
        public DateOnly HiringDate { get; set; }
    }
}
