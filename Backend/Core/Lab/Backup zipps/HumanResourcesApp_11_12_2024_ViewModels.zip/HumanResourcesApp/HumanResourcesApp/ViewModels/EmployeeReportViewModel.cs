﻿namespace HumanResourcesApp.ViewModels
{
    public class EmployeeReportViewModel
    {
        public int EmployeeCount { get; set; }        
        public decimal TotalSSA { get; set; }
        public decimal TotalBasicSalries { get; set; }        
        public decimal TotalBonuses { get; set; }
        public decimal TotalNetSalaries { get; set; }

    }
}
