﻿using HumanResourcesApp.Models;
using Microsoft.AspNetCore.Mvc;


namespace HumanResourcesApp.Controllers
{
    public class EmployeeController : Controller
    {
        private static List<Employee> _employeesList = new List<Employee>
        {
            new Employee {Id = 1, EmployeeName = "John Smith", DepartmentId = 2, HiringDate = DateTime.Parse("12/03/2015")},              // using .Parse()
            new Employee {Id = 2, EmployeeName = "Sarah Adams", DepartmentId = 1, HiringDate = Convert.ToDateTime("2020, 12, 24") },  // using Convert()
            new Employee {Id = 3, EmployeeName = "Ali Hamed", DepartmentId = 3, HiringDate = new DateTime(2022, 11, 05)},                  // using new DateTime creating new instance of DateTime
            new Employee {Id = 4, EmployeeName = "William Henry", DepartmentId = 4, HiringDate = DateTime.Parse("12/09/2019")}               // using Parse()
        };

        // Show all Employees
        public IActionResult Index()
        {
            // join _employees with _departments
            var employees = (from emp in _employeesList
                             join dept in DepartmentController._departmentsList
                             on emp.DepartmentId equals dept.Id
                             select new Employee
                             {
                                 Id = emp.Id,
                                 EmployeeName = emp.EmployeeName,
                                 DepartmentId = emp.DepartmentId,
                                 HiringDate = emp.HiringDate,
                                 DepartmentName = dept.DepartmentName
                             }).ToList();

            return View(employees);
        }

        // Create new employee menu
        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.DepartmentList = DepartmentController._departmentsList.ToList();
            return View();
        }
        // Add the created employee from Create - Get to _employeeList
        [HttpPost]
        public IActionResult Create(Employee employee)
        {
            if (employee != null && employee.Id > 0)
            {
                _employeesList.Add(employee);
                return RedirectToAction("index");
            }
            else
            {
                return View();
            }
        }

        // Edit Employee Menu
        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.DepartmentList = DepartmentController._departmentsList.ToList();

            var emp = _employeesList.Where(emp => emp.Id == id).FirstOrDefault();

            return View(emp);
        }
        // Update edited employee information from Edit-Get and save them.
        [HttpPost]
        public IActionResult Edit(int id, Employee employee)
        {
            var emp = _employeesList.Where(emp => emp.Id == id).FirstOrDefault();

            emp.EmployeeName = employee.EmployeeName;
            emp.DepartmentId = employee.DepartmentId;
            emp.DepartmentName = employee.DepartmentName;
            emp.HiringDate = employee.HiringDate;

            return RedirectToAction("index");
        }

        // Employee Delete menu
        [HttpGet]
        //public IActionResult Delete(int id)
        //{
        //    var model = _employeesList.Find(emp => emp.Id == id);
        //    return RedirectToAction(nameof(Index));

        //    return View(model);
        //}

        // The Delete - Post action method below is no longer needed now since we added onClick event in Index view file inside Delete button.

        // Remove selected employee from _employeeList
        [HttpGet]
        public IActionResult Delete(int id, Employee employee)
        {
            var model = _employeesList.Find(emp => emp.Id == id);
            if (model != null)
            {
                _employeesList.Remove(model);
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
