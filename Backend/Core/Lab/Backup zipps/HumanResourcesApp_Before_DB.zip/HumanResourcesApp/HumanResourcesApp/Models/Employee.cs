﻿using System.ComponentModel.DataAnnotations;

namespace HumanResourcesApp.Models
{
    public class Employee
    {
        // Data Annotation
        [Required(ErrorMessage = "Value Cannot be Zero or empty.")]
        [Display(Name = "Employee ID")]
        [Range(1, int.MaxValue)]  // Check input is positive value        
        public int Id { get; set; }

        [Required]
        [Display(Name = "Employee Name")]
        [StringLength(20)]  // Check input length
        public string EmployeeName { get; set; }

        [Required]
        [Display(Name = "Department")]
        public int DepartmentId { get; set; } // DepartmentId foreign key 

        [Required]
        [Display(Name = "Department")]
        public string DepartmentName { get; set; }

        [Required]
        [Display(Name = "Hiring Date")]
        public DateTime HiringDate { get; set; }
    }
}
